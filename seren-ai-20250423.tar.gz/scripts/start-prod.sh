#!/bin/bash

# Seren AI - Production Start Script
# This script starts the Seren AI system in production mode

NODE_ENV=production node server/index.js