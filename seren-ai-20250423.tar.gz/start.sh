#!/bin/bash

# Seren AI - Startup Script
NODE_ENV=production node server/index.js
