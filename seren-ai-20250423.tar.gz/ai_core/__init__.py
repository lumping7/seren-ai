"""
AI Core for Seren

Contains the core AI components for the Seren system.
"""