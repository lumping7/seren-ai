"""
Knowledge Library for Seren

Provides shared knowledge storage, retrieval, and learning
mechanisms for the AI models.
"""