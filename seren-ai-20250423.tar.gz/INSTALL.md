# Seren AI Quick Installation Guide

1. Unpack the archive:
   ```bash
   tar -xzf seren-ai.tar.gz
   cd seren
   ```

2. Run the installation script:
   ```bash
   ./setup-production.sh
   ```

3. Start the application:
   ```bash
   npm run start:prod
   ```

For detailed instructions, see the README.md file.
